const Components: React.FC = () => (
  <div>
    This is Components page!
  </div>
);

export default Components;
