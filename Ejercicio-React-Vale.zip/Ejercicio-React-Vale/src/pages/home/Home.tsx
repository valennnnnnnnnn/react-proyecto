const Home: React.FC = () => (
  <div>
    This is Home page!
  </div>
);

export default Home;
